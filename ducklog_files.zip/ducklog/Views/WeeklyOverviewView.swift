import SwiftUI

struct WeeklyOverviewView: View {
    @ObservedObject var viewModel: JournalViewModel
    
    var grouped: [String: [JournalEntry]] {
        Dictionary(grouping: viewModel.filteredEntries) {
            let formatter = DateFormatter()
            formatter.dateFormat = "EEEE"
            return formatter.string(from: $0.timestamp)
        }
    }
    
    var body: some View {
        ScrollView {
            ForEach(grouped.keys.sorted(), id: \ .self) { day in
                Section(header: Text(day).font(.headline)) {
                    ForEach(grouped[day] ?? []) { entry in
                        VStack(alignment: .leading) {
                            Text(entry.formattedTime)
                                .font(.caption)
                            Text(entry.content)
                                .lineLimit(2)
                            Divider()
                        }
                    }
                }
                .padding(.bottom, 8)
            }
        }
        .padding()
    }
} 