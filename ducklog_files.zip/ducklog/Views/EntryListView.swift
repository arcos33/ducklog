import SwiftUI

struct EntryListView: View {
    @ObservedObject var viewModel: JournalViewModel
    
    var body: some View {
        List(viewModel.filteredEntries) { entry in
            VStack(alignment: .leading) {
                Text(entry.content.prefix(60))
                    .font(.headline)
                Text(entry.formattedTime)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .onTapGesture {
                viewModel.selectedEntry = entry
            }
        }
    }
} 