import SwiftUI

struct SettingsView: View {
    @ObservedObject var viewModel: SettingsViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Summary Template")) {
                    ForEach(viewModel.settings.sectionOrder, id: \ .self) { section in
                        Toggle(section, isOn: Binding(
                            get: { viewModel.settings.templateSections.contains(section) },
                            set: { _ in viewModel.toggleSection(section) }
                        ))
                    }
                    .onMove { from, to in
                        viewModel.moveSection(from: from, to: to)
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
} 