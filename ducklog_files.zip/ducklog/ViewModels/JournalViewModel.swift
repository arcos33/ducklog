import Foundation
import Combine

class JournalViewModel: ObservableObject {
    @Published var entries: [JournalEntry] = []
    @Published var selectedEntry: JournalEntry?
    @Published var filter: TimeFilter = .lastWeek
    
    private let markdownService = MarkdownFileService.shared
    private var cancellables = Set<AnyCancellable>()
    
    enum TimeFilter {
        case lastWeek
        case twoWeeks
        case threeWeeks
        
        var startDate: Date {
            let calendar = Calendar.current
            let now = Date()
            switch self {
            case .lastWeek:
                return calendar.date(byAdding: .day, value: -7, to: now)!
            case .twoWeeks:
                return calendar.date(byAdding: .day, value: -14, to: now)!
            case .threeWeeks:
                return calendar.date(byAdding: .day, value: -21, to: now)!
            }
        }
    }
    
    init() {
        loadEntries()
    }
    
    func addEntry(content: String, tags: [String] = [], status: String = "In Progress") {
        let entry = JournalEntry(
            id: UUID(),
            timestamp: Date(),
            content: content,
            tags: tags,
            status: status
        )
        entries.insert(entry, at: 0)
        try? markdownService.saveEntry(entry)
    }
    
    func loadEntries() {
        do {
            entries = try markdownService.loadEntries()
        } catch {
            print("Error loading entries: \(error)")
        }
    }
    
    var filteredEntries: [JournalEntry] {
        entries.filter { $0.timestamp >= filter.startDate }
    }
} 