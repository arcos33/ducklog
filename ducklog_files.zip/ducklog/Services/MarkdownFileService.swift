import Foundation

class MarkdownFileService {
    static let shared = MarkdownFileService()
    
    private let fileManager = FileManager.default
    private let journalFileName = "ducklog_journal.md"
    
    private init() {}
    
    func getDocumentsDirectory() -> URL {
        fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func saveEntry(_ entry: JournalEntry) throws {
        let markdown = """
        # \(entry.formattedTime)
        Status: \(entry.status)
        Tags: \(entry.tags.joined(separator: ", "))
        \(entry.linkedPullRequest != nil ? "PR: \(entry.linkedPullRequest!.title)" : "")
        
        \(entry.content)
        
        ---
        
        """
        
        let fileURL = getDocumentsDirectory().appendingPathComponent(journalFileName)
        
        if !fileManager.fileExists(atPath: fileURL.path) {
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
        } else {
            let handle = try FileHandle(forWritingTo: fileURL)
            handle.seekToEndOfFile()
            handle.write(markdown.data(using: .utf8)!)
            handle.closeFile()
        }
    }
    
    func loadEntries() throws -> [JournalEntry] {
        // TODO: Implement markdown parsing
        return []
    }
} 