import Foundation

struct JournalEntry: Identifiable, Codable, Equatable {
    let id: UUID
    let timestamp: Date
    var content: String
    var tags: [String]
    var status: String
    var linkedPullRequest: GitHubPR?
    
    var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, h:mm a"
        return formatter.string(from: timestamp)
    }
}

struct GitHubPR: Codable, Equatable {
    let id: String
    let title: String
    let description: String
    let status: String
    let url: URL
} 